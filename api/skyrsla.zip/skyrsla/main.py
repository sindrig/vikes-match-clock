import argparse
import pprint
from collections import defaultdict
from suds.client import Client

WSDL_URL = 'http://www2.ksi.is/vefthjonustur/mot.asmx?WSDL'
VIKES = '103'

client = Client(WSDL_URL)


def get_player(player):
    return {
        'number': player.TreyjuNumer,
        'name': player.LeikmadurNafn.strip(),
        'role': player.StadaNafn,
    }


def handler(json_input, context):
    game = client.service.LeikurLeikmenn(LeikurNumer=json_input['match_id'])
    result = defaultdict(list)
    for player in game.ArrayLeikurLeikmenn.LeikurLeikmenn:
        result[player.FelagNafn].append(get_player(player))
    return dict(result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('match_id')
    args = parser.parse_args()
    pprint.pprint(handler({'match_id': args.match_id}, None))
