
def is_builtin(name):
    return name.startswith('__') and name.endswith('__')
