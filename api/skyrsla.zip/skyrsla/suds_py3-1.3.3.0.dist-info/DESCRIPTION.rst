The "suds-p3" is a lightweight soap-based client for python3
licensed under LGPL. This is a mirror of http://svn.fedorahosted.org/svn/suds/trunk/
supporting Python3 and some fixes.

